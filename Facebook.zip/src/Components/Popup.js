import React, { useState } from "react";
import CreateIcon from '@mui/icons-material/Create';
import PhotoLibraryIcon from '@mui/icons-material/PhotoLibrary';
import VideoCameraFrontIcon from '@mui/icons-material/VideoCameraFront';
import AccountCircleIcon from '../Assets/male_user.png';
import SentimentVerySatisfiedIcon from '@mui/icons-material/SentimentVerySatisfied';
import ReactGiphySearchbox from "react-giphy-searchbox";
import { useForm } from "react-hook-form";




export default function Popup ( props )  {
 const {handleClose,Content, setContent , setPostGif,postGif}= props;
  const { register, handleSubmit , reset  } = useForm();
  const [result, setResult] = useState("");
  const [ShowGif, SetShwoGif] = useState(false)
  const onSubmit = (data) => {setResult(data.name); setContent([...Content, result]); reset();}
  
  

  return (
    <div className="popup-box">
      <div className="box">
        <span className="close-icon" onClick={handleClose}>x</span>
        <div className="Popup_Nav">
          <div className="Nav_Item">
            <CreateIcon />
            <p> Compose Post</p>
            <div className="vl"></div>
            <PhotoLibraryIcon />
            <p className="Nav_P">Photo/video Album</p>
            <div className="vl"></div>
            <VideoCameraFrontIcon />
            <p className="Nav_P">Live video</p>
          </div>
        </div>
        
        
        <form onSubmit={handleSubmit(onSubmit)}>
        <div className="SearchBar">
          <img className="male_user" src={AccountCircleIcon} alt="male" />
          <div>
          <input className="Serch_Input" placeholder="Write Something Here..."
          {...register("name") }
              />
               <p>{result}</p>
              
      {/* <input type="submit" /> */}
       </div>
      </div>
  
     
     
        <div className="Colors">
          <button className="Colors_btn" style={{ background: "#A2416B" }} ></button>
          <button className="Colors_btn" style={{ background: "#DEEDF0" }}></button>
          <button className="Colors_btn" style={{ background: "#FF5DA2" }}></button>
          <button className="Colors_btn" style={{ background: "#3F0713" }}></button>
          <button className="Colors_btn" style={{ background: "#FCFFA6" }} ></button>
          <button className="Colors_btn" style={{ background: "#B97A95" }} ></button>
          <button className="Colors_btn" style={{ background: "#290FBA" }}  ></button>
          <button className="Colors_btn" style={{ background: "#716F81" }} ></button>
          <button className="Colors_btn" style={{ background: "#FF3D68" }} ></button>
          <button className="Colors_btn" style={{ background: "#7952B3" }} ></button>
          <button className="Colors_btn" style={{ background: "#890596" }} ></button>
          <button className="Colors_btn" style={{ background: "#F8A1D1" }} ></button>
          <button className="Colors_btn" style={{ background: "#64DFDF" }} ></button>
          <button className="Colors_btn" style={{ background: "#7F7C82" }} ></button>
          <button className="Colors_btn" style={{ background: "#FAFF00" }} ></button>
          <SentimentVerySatisfiedIcon style={{ color: "gray", width: "5rem", marginTop: "-2rem" }} />
        </div>
        <hr></hr>
        <div className="Features">
          <button className="Features_Buttons" >Tag Friends</button>
          <button className="Features_Buttons" > Check In</button>
          <button className="Features_Buttons" onClick={() => {SetShwoGif(!ShowGif);} }>GIF </button>
          <button className="Features_Buttons" > Tag Event</button>
        </div>
        <hr></hr>
        <diV className="Post_Button">
        <button className="Only_me" >Only ME</button>
        <button className="Post" type="submit" >Post</button>
        </diV>
        </form>
        <div className={ShowGif ?"searchboxWrapper" : "none"}>
          <ReactGiphySearchbox
            apiKey="9Ixlv3DWC1biJRI57RanyL7RTbfzz0o7"
            onSelect={(item) => {
              setPostGif([...postGif, item]);

            }}
            masonryConfig={[
              { columns: 2, imageWidth: 110, gutter: 5 },
              { mq: "700px", columns: 3, imageWidth: 120, gutter: 5 }
            ]}
          />
        </div>
        <div>
          {postGif.map((obj, index) => {

            return (
              <div key={index}>
                <h1>{index}</h1>
                <img src={obj.images.fixed_height.url} alt="" />

              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

